package gitmad.gatech.edu.project2340.Model;

public class Person {
}
