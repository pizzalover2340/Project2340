package gitmad.gatech.edu.project2340.Model;

public class Manager extends Person {
}
