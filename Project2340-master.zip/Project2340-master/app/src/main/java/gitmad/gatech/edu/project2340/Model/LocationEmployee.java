package gitmad.gatech.edu.project2340.Model;

public class LocationEmployee extends Person {
}
