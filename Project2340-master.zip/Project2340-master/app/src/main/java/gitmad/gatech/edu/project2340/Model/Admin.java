package gitmad.gatech.edu.project2340.Model;

public class Admin extends Person {
}
